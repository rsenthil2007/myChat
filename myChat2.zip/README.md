# myChat

Simple web chat with **text** and **freehand canvas drawings**. HTML/CSS/JS + JSON rooms. Easy to wrap as a mobile app.

## Why Chrome ↔ Edge did not sync before

`python -m http.server` only serves files. Messages were stored in each browser’s `localStorage`, so Chrome and Edge could not see each other.

## Run (shared rooms across browsers)

```bash
pip install -r requirements.txt
python server.py
```

- Desktop: **http://localhost:8080**
- Phone (text / draw / play audio): **http://YOUR-PC-IP:8080**
- Phone (**record audio**): **https://YOUR-PC-IP:8443**  
  Accept the certificate warning once (Advanced → Proceed). Chrome blocks the mic on plain `http://192.168.x.x`.

Join the **same room** on all devices. Messages sync through `data/rooms/{room}.json`.

## Security & compression

Outbound payloads are **deflate-compressed when it saves space**, then sealed with
**SHA-256 keystream + HMAC**. Short texts may stay uncompressed; drawings/audio JSON usually shrink.
Works on modern Chrome / Edge / Android (CompressionStream). Room code is the shared key.

## Voice notes

Hold the mic (desktop) or **tap to start / tap to send** (phone). Max 60s.  
On phones, open the **HTTPS :8443** URL first or recording will be blocked.

## Shared whiteboard

In a room, open the **Board** tab:

1. Everyone draws on the same board; each person gets their own **transparent layer**.
2. Opening the board assigns a unique **standard color** (Red, Green, Blue, Black, Orange, …).
3. Sketch toolkit: **Pen, Eraser, Line, Arrow, Rect, Circle, Oval, Text** (plus size + custom color).
4. Swatches + custom picker stay available — you may use multiple free colors on your layer.
5. Colors already used by others in the room are blocked (including near-matches).
6. **Undo** / **Clear mine** only affect *your* strokes; **Clear all** resets layers and color claims.

## Pictionary (optional)

Game code remains in the project but the tab is **hidden by default** for a professional Chat + Board experience.

To show it again, set `FEATURES.pictionary = true` in `js/app.js` and hard-refresh.

When enabled:
1. Someone taps **I'll draw** (they alone see the word)
2. Drawer sketches — strokes sync to everyone
3. Others type guesses — correct guess scores drawer + guesser
4. Tap **I'll draw** again for the next round

## Tests

```bash
python tests/test_suite.py
```

Covers room isolation, clear-via-API, clear push over SSE, Pictionary rules, whiteboard layers/colors/undo, secure envelope validation, path hardening, and crypto.

## Project layout

```
myChat/
  server.py          # static files + /api/rooms API
  whiteboard.py      # shared board layers / undo
  pictionary_game.py
  index.html
  css/style.css
  js/app.js
  js/storage.js
  js/canvas-draw.js
  js/whiteboard.js
  js/pictionary.js
  data/rooms/        # shared room JSON files (created at runtime)
  manifest.webmanifest
```

## Wrap as a mobile app (WebInto.app / Capacitor)

Permissions needed for the current feature set:

| Feature | Android permission |
| --- | --- |
| Chat / Board / SSE | `INTERNET`, `ACCESS_NETWORK_STATE` |
| Voice notes | `RECORD_AUDIO`, `MODIFY_AUDIO_SETTINGS` |

Ready-to-use files:

- `android/AndroidManifest.permissions.xml` — paste into Capacitor/Cordova manifest
- `android/webintoapp-permissions.json` — WebInto.app checklist (`AUDIO` permission)
- `js/native-bridge.js` — asks WebInto.app for mic permission before `getUserMedia`

**WebInto.app tips**

1. Point the app at your **HTTPS** myChat URL (WebView mic needs a secure context).
2. Enable **Microphone / Audio** in the builder permissions.
3. Prefer a real TLS certificate for packaged apps; self-signed LAN certs often fail inside WebView.
4. Camera / location / storage are **not** required.

Point Capacitor `webDir` at this folder. For real multi-device chat, host `server.py` (or a cloud API) and point the app at that base URL.

## Optional next steps

- Auth / room passwords
- Migrate LAN crypto to Web Crypto AES-GCM when HTTPS-only is acceptable
- Deploy API to a VPS for phones outside your LAN
